from functions import (
    save_session_data,
    clear_session_data,
    now_iso,
    session_data,
)
from constants import SessionState
from lang_dicts import *
from TeleClientSingleton import TeleClientSingleton
from TeleBotSingleton import TeleBotSingleton
from Config import Config
import mobi_cash as mobi

from telethon.tl.functions.channels import EditBannedRequest, LeaveChannelRequest
from telethon.tl.types import ChatBannedRights
from telethon import events, Button
import models
import json
import logging
import os
from datetime import datetime
import re
from sqlalchemy.orm import Session
from google.cloud import vision
from PIL import Image, ImageEnhance, ImageFilter
from openai import AsyncOpenAI


log = logging.getLogger(__name__)

openai = AsyncOpenAI(api_key=Config.OPENAI_API_KEY)


async def get_receipt(event: events.NewMessage.Event):
    if not event.is_group or not event.photo:
        return
    cid = event.chat_id
    uid = event.sender_id
    ent = await TeleClientSingleton().get_entity(cid)
    with models.session_scope() as s:
        user_session = s.query(models.UserSession).filter_by(group_id=ent.id).first()
        user = s.get(models.User, uid)
        if user_session and uid == user_session.user_id:
            user_account = s.query(models.PlayerAccount).filter_by(user_id=uid).first()
            if not user_account:
                await TeleClientSingleton().send_message(
                    entity=cid,
                    message=TEXTS[user.lang]["no_account"],
                )
                return
            st = user_session.session_type
            if st != "deposit":
                await TeleClientSingleton().send_message(
                    entity=cid,
                    message=f"Receipts can only be send in deposit sessions, withdraw info must be provided manualy.",
                )
                return

            extracted, parsed_details = await extract_text_from_photo(
                event=event,
                lang=user.lang,
                payment_methods=list(
                    map(
                        str,
                        s.query(models.PaymentMethod)
                        .filter(models.PaymentMethod.type.in_([st, "both"]))
                        .all(),
                    )
                ),
            )
            if extracted:
                if parsed_details["transaction_id"]:
                    transaction_id = parsed_details["transaction_id"]
                    duplicate = (
                        s.query(models.Receipt)
                        .filter(models.Receipt.id == transaction_id)
                        .first()
                    )
                    if (
                        duplicate
                        and duplicate.user_id is not None
                        and duplicate.user_id != uid
                    ):
                        await handle_fraud(
                            uid=uid,
                            cid=cid,
                            st=st,
                            user=user,
                            duplicate=duplicate,
                            extracted=extracted,
                            transaction_id=transaction_id,
                            s=s,
                        )
                        return
                details_str = "".join(
                    [
                        f"{k}: {v}\n"
                        for k, v in parsed_details.items()
                        if v and k in session_data[uid][st]["data"]
                    ]
                )
                if not all(
                    parsed_details[f]
                    for f in session_data[uid]["metadata"]["required_deposit_fields"]
                ):
                    missing = []
                    for k in session_data[uid]["metadata"]["required_deposit_fields"]:
                        if not parsed_details[k]:
                            missing.append(k)
                        else:
                            session_data[uid][st]["data"][k] = parsed_details[k]
                    msg = (
                        f"text extracted from photo:\n\n"
                        f"<code>{details_str}</code>\n"
                        f"but we have a missing details: ({', '.join(missing)}). Please provide them manually"
                    )
                else:
                    for f in session_data[uid]["metadata"]["required_deposit_fields"]:
                        session_data[uid][st]["data"][f] = parsed_details[f]
                    msg = (
                        f"Receipt verified successfully, required fields extracted:\n\n"
                        f"<code>{details_str}</code>\n\n"
                    )
                    msg += "You can send OK if all the information are correct."
                if "date" not in parsed_details:
                    log.info(f"تفاصيل اختيارية مفقودة: ['date']")
                    msg += "optional fields (date) are missing, please provide them manually if they're present."
                else:
                    session_data[uid][st]["data"]["date"] = parsed_details["date"]
                await TeleClientSingleton().send_message(
                    entity=cid, message=msg, parse_mode="html"
                )

            save_session_data()
    raise events.StopPropagation


async def get_missing(event: events.NewMessage.Event):
    if not event.is_group or event.photo:
        return
    cid = event.chat_id
    uid = event.sender_id
    ent = await TeleClientSingleton().get_entity(cid)
    with models.session_scope() as s:
        default_prompt = s.get(models.Setting, "gpt_prompt")
        user_session = s.query(models.UserSession).filter_by(group_id=ent.id).first()
        user = s.get(models.User, uid)
        if user_session and uid == user_session.user_id:
            user_account = s.query(models.PlayerAccount).filter_by(user_id=uid).first()
            if not user_account:
                await TeleClientSingleton().send_message(
                    entity=cid,
                    message=TEXTS[user.lang]["no_account"],
                )
                return
            st = user_session.session_type
            session_prompt = s.get(models.Setting, f"gpt_prompt_{st}")
            payment_methods = list(
                map(
                    str,
                    s.query(models.PaymentMethod)
                    .filter(models.PaymentMethod.type.in_([st, "both"]))
                    .all(),
                )
            )
            txt: str = event.raw_text
            system_msg = (
                f"This message was sent by user {uid} in a {st} session\n"
                f"the state of the conversation is {session_data[uid][st]['state']} and the data we have is {session_data[uid][st]['data']}\n"
                f"the user just sent the msg '{txt}' if we're at AWAITING_MISSING_FIELDS state and the msg contains one of the missing fields please extract it and respond only with it in a JSON like the data I previously provided\n"
                f"the payment methods we have in case the user msg contained one: {payment_methods}\n"
                "Important Notes:"
                "- Don't use single quotes\n"
                "- Dates in ISO format\n"
                "- Withdrawal codes are mix of numbers and letters with no meaning whatsoever\n"
                "- Payment info is like a bank account number, a wallet address, an IBAN number or something similar\n"
                "if the msg was a question or something other than a data just respond to it in its language as the following\n"
                f"{session_prompt.value if session_prompt else default_prompt.value}"
            )
            resp = await openai.chat.completions.create(
                model=Config.GPT_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": system_msg,
                    },
                    {
                        "role": "user",
                        "content": txt,
                    },
                ],
                temperature=0.7,
            )
            reply = resp.choices[0].message.content.strip()
            try:
                if "```json" in reply:
                    reply = reply.split("```json")[1].split("```")[0].strip()
                parsed_details: dict = json.loads(r"{}".format(reply))
                for d in parsed_details:
                    session_data[uid][st]["data"][d] = parsed_details[d]
                provided_data = "".join(
                    [f"{k}: {v}\n" for k, v in parsed_details.items() if v]
                )
                user_msg = (
                    f"missing/edited info recieved:\n\n"
                    f"<code>{provided_data}</code>\n"
                )
                if parsed_details.get("transaction_id", None):
                    transaction_id = parsed_details["transaction_id"]
                    duplicate = (
                        s.query(models.Receipt)
                        .filter(models.Receipt.id == transaction_id)
                        .first()
                    )
                    if (
                        duplicate
                        and duplicate.user_id is not None
                        and duplicate.user_id != uid
                    ):
                        await handle_fraud(
                            uid=uid,
                            cid=cid,
                            st=st,
                            user=user,
                            duplicate=duplicate,
                            extracted=reply,
                            transaction_id=transaction_id,
                            s=s,
                        )
                        return
                if all(
                    session_data[uid][st]["data"][f]
                    for f in session_data[uid]["metadata"][f"required_{st}_fields"]
                ):
                    completed_data = "".join(
                        [
                            f"{k}: {v}\n"
                            for k, v in session_data[uid][st]["data"].items()
                            if v
                        ]
                    )
                    user_msg += (
                        "Required data completed:\n\n"
                        f"<code>{completed_data}</code>\n"
                        "you can send OK if all the information are correct.\n\n"
                        "Note that withdrawal take <b>from 1 up to 24 hours</b> to complete"
                    )
                    session_data[uid][st][
                        "state"
                    ] = SessionState.AWAITING_CONFIRMATION.name
                else:
                    missing_data = "".join(
                        [
                            f"{k}: {v}\n"
                            for k, v in session_data[uid][st]["data"].items()
                            if not v
                        ]
                    )
                    user_msg += (
                        "Required fields not yet provided:\n\n"
                        f"<code>{missing_data}</code>\n"
                        "Please provide them manualy."
                    )

            except json.decoder.JSONDecodeError:
                user_msg = reply
            await TeleClientSingleton().send_message(
                entity=cid,
                message=user_msg,
                parse_mode="html",
            )
            save_session_data()
    raise events.StopPropagation


async def send_transaction_to_proccess(event: events.NewMessage.Event):
    uid = event.sender_id
    if not event.is_group or not event.raw_text:
        return
    cid = event.chat_id
    ent = await TeleClientSingleton().get_entity(cid)
    with models.session_scope() as s:
        user_session = s.query(models.UserSession).filter_by(group_id=ent.id).first()
        user = s.get(models.User, uid)
        if user_session and uid == user_session.user_id:
            user_account = s.query(models.PlayerAccount).filter_by(user_id=uid).first()
            st = user_session.session_type
            if (
                session_data[uid][st]["state"]
                != SessionState.AWAITING_CONFIRMATION.name
            ):
                return
            if not user_account:
                await TeleClientSingleton().send_message(
                    entity=cid,
                    message=TEXTS[user.lang]["no_account"],
                )
                return
            if st == "withdraw":
                res = await auto_withdraw(user=user, s=s)
            else:
                res = await auto_deposit(user=user, s=s)
            if not isinstance(res, int):
                await TeleClientSingleton().send_message(
                    entity=cid,
                    message=TEXTS[user.lang][f"{st}_failed"].format(res),
                )
                return
            await kick_user_and_admin(
                gid=user_session.group_id, uid=user_session.user_id
            )
            await TeleClientSingleton().send_message(
                entity=uid,
                message=(
                    f"Alright we're processing your transaction number <code>{res}</code>, and we'll catch up with you soon\n\n"
                    "Note that withdrawal take <b>from 1 up to 24 hours</b> to complete"
                ),
                parse_mode="html",
            )
            clear_session_data(user_id=uid, st=st)
    raise events.StopPropagation


async def extract_text_from_photo(event, lang, payment_methods):
    path = None
    photo_name = "photo.jpg"
    try:
        # تحميل الصورة من تيليجرام
        path = await event.download_media(file=photo_name)

        # (اختياري) معالجة الصورة للتوضيح، إذا أردت
        img = Image.open(path).convert("L")
        img = img.filter(ImageFilter.SHARPEN)
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(2.5)
        img.save(photo_name)
        img_path_to_send = photo_name

        # إنشاء عميل Google Vision
        client = vision.ImageAnnotatorClient()
        with open(img_path_to_send, "rb") as image_file:
            content = image_file.read()

        image = vision.Image(content=content)
        response = client.text_detection(image=image)
        texts = response.text_annotations

        if not texts:
            log.warning("لم يتم استخراج أي نص من الصورة.")
            await event.reply(TEXTS[lang]["no_text_extracted_from_photo"])
            return None, None

        text = texts[0].description.strip()
        cleaned_text = re.sub(
            r"[^\w\s\d.:/-إأآابتثجحخدذرزسشصضطظعغفقكلمنهويةى]", "", text
        )
        log.info(f"النص المستخرج: {cleaned_text}")
        resp = await openai.chat.completions.create(
            model=Config.GPT_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": (
                        f"You are a professional financial assistant.\n\n"
                        "Given the following payment or bank receipt text, analyze and extract all relevant fields.\n"
                        "Return your full response as a single JSON object with these fields:\n"
                        "- transaction_id (string)\n"
                        "- from (sender name, string)\n"
                        "- to (recipient name, string)\n"
                        "- amount (string/float)\n"
                        "- currency (string)\n"
                        f"- payment_method from our list of payment methods {payment_methods}\n"
                        "- date (in iso format)\n"
                        "- warnings (array of strings, if any field is suspicious or missing, else empty array)\n"
                        "- summary_ar (string, clear summary in Arabic)\n"
                        "- summary_en (string, clear summary in English)\n\n"
                        "If a field is missing, set its value to null.\n"
                        "If you detect other relevant info (such as extra logo, country, etc) add a field 'extra' as an object.\n\n"
                        "Output ONLY a valid JSON object, without any extra explanation or text.\n\n"
                        "Receipt OCR text:\n\n"
                        f"{cleaned_text}\n\n"
                        "Pre-parsed fields (for reference, use or correct them as needed):"
                    ),
                }
            ],
            temperature=0.7,
        )
        content = resp.choices[0].message.content.strip()
        if "```json" in content:
            json_part = content.split("```json")[1].split("```")[0].strip()
        parsed_details = json.loads(r"{}".format(json_part))
        return cleaned_text, parsed_details

    except Exception as e:
        log.error(f"خطأ في OCR (Google Vision): {e}")
        await event.reply(TEXTS[lang]["google_vision_error"])
        return None, None

    finally:
        if path and os.path.exists(path):
            os.remove(path)


async def kick_user_and_admin(gid: int, uid: int):
    try:
        peer = await TeleClientSingleton().get_entity(gid)
        await TeleClientSingleton()(
            EditBannedRequest(
                channel=peer,
                participant=await TeleClientSingleton().get_entity(uid),
                banned_rights=ChatBannedRights(until_date=None, view_messages=True),
            )
        )
        await TeleClientSingleton()(LeaveChannelRequest(channel=peer))

        log.info(f"تم طرد المستخدم {uid} والمدير {Config.ADMIN_ID} من المجموعة {gid}.")
    except Exception as e:
        log.error(f"خطأ أثناء الطرد: {e}")


async def handle_fraud(
    uid: int,
    cid: int,
    st: str,
    user: models.User,
    duplicate: models.Receipt,
    extracted: str,
    transaction_id: int,
    s: Session,
):
    from_user = s.get(models.User, duplicate.user_id)
    s.add(
        models.FraudLog(
            user_id=uid,
            copied_from_id=duplicate.user_id,
            timestamp=now_iso(),
            receipt_text=extracted,
            transaction_id=transaction_id,
        )
    )
    s.commit()
    count = s.query(models.FraudLog).filter_by(user_id=uid).count()
    if count >= 5:
        s.add(
            models.Blacklist(
                user_id=uid,
                timestamp=now_iso(),
            )
        )
        s.commit()
        user_msg = (
            "Fraud attempt detected.\n"
            f"This transaction (ID: {transaction_id}) was sent by another user.\n"
            f"This is your attempt number {count}.\n"
            "You have been added to the blacklist."
        )
        admin_msg = (
            f"المستخدم @{user.username} (<code>{uid}</code>) في القائمة السوداء عدد المحاولات {count} ⚠️\n"
            f"رقم العملية الذي تمت المحاولة فيه: <code>{transaction_id}</code>\n"
            f"عائد للمستخدم @{from_user.username} (<code>{duplicate.user_id}</code>)"
        )
    else:
        user_msg = (
            "Fraud attempt detected.\n"
            f"This transaction (ID: {transaction_id}) was sent by another user.\n"
            f"This is your attempt number {count}.\n"
            "Note that if you reach 5 attempts, you will be blacklisted."
        )
        admin_msg = (
            f"محاولة احتيال رقم {count} للمستخدم @{user.username} (<code>{uid}</code>) ⚠️\n"
            f"رقم العملية الذي تمت المحاولة فيه: <code>{transaction_id}</code>\n"
            f"عائد للمستخدم @{from_user.username} (<code>{duplicate.user_id}</code>)"
        )
    await TeleClientSingleton().send_message(entity=cid, message=user_msg)
    await TeleClientSingleton().send_message(entity=Config.ADMIN_ID, message=admin_msg)
    if count >= 5:
        await kick_user_and_admin(gid=cid, uid=uid)
        clear_session_data(user_id=uid, st=st)


async def auto_deposit(user: models.User, s: Session):
    st = "deposit"
    data = session_data[user.id][st]["data"]
    payment_method = (
        s.query(models.PaymentMethod).filter_by(name=data["payment_method"]).first()
    )
    transaction = add_transaction(
        data=data, user_id=user.id, st=st, payment_method_id=payment_method.id, s=s
    )
    if payment_method.mode == "auto":
        # TODO auto check if deposit arrived
        res = mobi.deposit(
            user_id=user.player_account.account_number, amount=data["amount"]
        )
        if res["Success"]:
            await TeleBotSingleton().send_message(
                entity=Config.ADMIN_ID,
                message=str(transaction),
                parse_mode="html",
            )
            return transaction.id
        return res["Message"]
    elif payment_method.name.lower() in ["e & money", "paydu", "payby"]:
        receipt = s.query(models.Receipt).filter_by(id=transaction.receipt_id).first()
        if receipt and not receipt.user_id:
            receipt.user_id = user.user_id
            s.commit()
            await TeleBotSingleton().send_message(
                entity=Config.ADMIN_ID,
                message=str(transaction),
                parse_mode="html",
            )
            return transaction.id
        return "Duplicate Receipt Id"
    else:
        await TeleBotSingleton().send_message(
            entity=Config.ADMIN_ID,
            message=str(transaction),
            parse_mode="html",
            buttons=(
                [
                    [
                        Button.inline(
                            text="موافقة ✅",
                            data=f"approve_{st}_{transaction.id}",
                        ),
                        Button.inline(
                            text="رفض ❌",
                            data=f"decline_{st}_{transaction.id}",
                        ),
                    ]
                ]
            ),
        )
        return transaction.id


async def auto_withdraw(user: models.User, s: Session):
    st = "withdraw"
    data = session_data[user.id][st]["data"]
    payment_method = (
        s.query(models.PaymentMethod).filter_by(name=data["payment_method"]).first()
    )
    transaction = add_transaction(
        data=data, user_id=user.id, st=st, payment_method_id=payment_method.id, s=s
    )
    res = mobi.withdraw(
        user_id=user.player_account.account_number,
        code=data["withdrawal_code"],
    )
    if res["Success"]:
        await TeleBotSingleton().send_message(
            entity=Config.ADMIN_ID,
            message=str(transaction),
            parse_mode="html",
            buttons=(
                [
                    [
                        Button.inline(
                            text="موافقة ✅",
                            data=f"approve_{st}_{transaction.id}",
                        ),
                        Button.inline(
                            text="رفض ❌",
                            data=f"decline_{st}_{transaction.id}",
                        ),
                    ]
                ]
            ),
        )
        return transaction.id
    return res["Message"]


def add_transaction(
    data: dict, user_id: int, st: str, payment_method_id: int, s: Session
):
    player_account = s.query(models.PlayerAccount).filter_by(user_id=user_id).first()
    if st == "deposit":
        transaction = models.Transaction(
            user_id=user_id,
            payment_method_id=payment_method_id,
            type=st,
            amount=data["amount"],
            currency=data["currency"],
            receipt_id=data["transaction_id"],
            player_account=player_account.account_number,
            status="pending",
            date=datetime.fromisoformat(data["date"]) if data["date"] else None,
            timestamp=now_iso(),
        )
    else:
        transaction = models.Transaction(
            user_id=user_id,
            payment_method_id=payment_method_id,
            type=st,
            withdrawal_code=data["withdrawal_code"],
            payment_info=data["payment_info"],
            player_account=player_account.account_number,
            status="pending",
            timestamp=now_iso(),
        )

    s.add(transaction)
    s.commit()
    return transaction
